import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Papa from "papaparse";

const COLUMNS_TO_SHOW = ["cmpd_id", "SMILES"];

const CsvPreview = () => {
  const location = useLocation();
  const baseUrl = "http://localhost:5001";  
  const fileUrl = location.state?.fileUrl ? `${baseUrl}${location.state.fileUrl}` : null;

  const [rawData, setRawData] = useState([]);

  useEffect(() => {
    if (fileUrl) {
      fetch(fileUrl)
        .then((response) => response.text())
        .then((csvText) => {
          const parsedResult = Papa.parse(csvText, { header: true });
          const filteredData = parsedResult.data.filter(
            (row) => Object.keys(row).length > 1
          );
          setRawData(filteredData);
        })
        .catch((error) => console.error("Error loading CSV:", error));
    }
  }, [fileUrl]);

  return (
    <div>
      <h2>CSV Preview</h2>
      {rawData.length > 0 ? (
        <div style={{ maxHeight: "600px", overflowY: "auto", border: "1px solid #ccc" }}>
          <table
            border="1"
            style={{
              width: "100%",
              borderCollapse: "collapse",
            }}
          >
            <thead>
              <tr>
                {COLUMNS_TO_SHOW.map((key) => (
                  <th key={key}>{key}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rawData.map((row, index) => (
                <tr key={index}>
                  {COLUMNS_TO_SHOW.map((colKey) => (
                    <td key={colKey}>{row[colKey]}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p>Loading CSV...</p>
      )}
    </div>
  );
};

export default CsvPreview;
